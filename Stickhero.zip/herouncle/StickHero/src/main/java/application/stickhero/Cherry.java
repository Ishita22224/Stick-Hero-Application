package application.stickhero;

public class Cherry extends Position {

    public Cherry() {
        createCherry();
    }
    public void createCherry() {
        // creates cherry at random position and returns the position
        this.setY(300);
    }
    public void removeCherry() {
        // remove cherry
    }

}
